//
//  testFBApp.swift
//  testFB
//
//  Created by Miguel Gómez Díaz on 03/05/23.
//

import SwiftUI
import Firebase

@main
struct testFBApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
